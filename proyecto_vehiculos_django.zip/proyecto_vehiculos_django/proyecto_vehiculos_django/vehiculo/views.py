
from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.models import User, Permission
from django.contrib.contenttypes.models import ContentType
from .forms import VehiculoForm
from .models import Vehiculo
from .forms import RegistroUsuarioForm

# Create your views here.

def index(request):
    return render(request, 'vehiculo/index.html', {'titulo': 'Catálogo de Vehículos'})

def add_vehiculo(request):
    if request.method == 'POST':
        form = VehiculoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = VehiculoForm()

    return render(request, 'vehiculo/add_vehiculo.html', {'form': form})

from django.contrib.auth.decorators import login_required, permission_required
from .models import Vehiculo

@login_required
@permission_required('vehiculo.visualizar_catalogo', raise_exception=True)  # Solo usuarios con el permiso pueden ver la lista
def list_vehiculos(request):
    vehiculos = Vehiculo.objects.all()
    
    for vehiculo in vehiculos:
        if vehiculo.precio <= 10000:
            vehiculo.condicion_precio = 'Bajo'
        elif 10000 < vehiculo.precio <= 30000:
            vehiculo.condicion_precio = 'Medio'
        else:
            vehiculo.condicion_precio = 'Alto'
    
    return render(request, 'vehiculo/list_vehiculos.html', {'vehiculos': vehiculos})

def registro(request):
    if request.method == 'POST':
        form = RegistroUsuarioForm(request.POST)
        if form.is_valid():
            user = form.save()

            content_type = ContentType.objects.get_for_model(Vehiculo)
            permiso, _ = Permission.objects.get_or_create(
                codename='visualizar_catalogo',
                name='Puede visualizar Catálogo de Vehículos',
                content_type=content_type
            )
            user.user_permissions.add(permiso)

            login(request, user)
            return redirect('index')
    else:
        form = RegistroUsuarioForm()

    return render(request, 'vehiculo/registro.html', {'form': form})